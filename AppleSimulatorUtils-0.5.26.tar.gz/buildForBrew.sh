targetDir="$1"

mkdir "$targetDir"/bin/
cp build/Build/Products/Release/applesimutils "$targetDir"/bin/applesimutils