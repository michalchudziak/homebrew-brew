targetDir="$1"

echo "$targetDir"
cp build/Build/Products/Release/applesimutils "$targetDir"/bin